import { NextResponse } from "next/server";
import crypto from "crypto";

// Verify Lemon Squeezy webhook signatures before processing subscription/token events.
// Persist entitlements in a real database before enabling paid features.
export async function POST(req: Request) {
  const secret = process.env.LEMONSQUEEZY_WEBHOOK_SECRET;
  const signature = req.headers.get("x-signature");
  const rawBody = await req.text();
  if (!secret || !signature) return NextResponse.json({ error: "Webhook is not configured." }, { status: 503 });

  const digest = crypto.createHmac("sha256", secret).update(rawBody).digest("hex");
  const a = Buffer.from(digest);
  const b = Buffer.from(signature);
  if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) {
    return NextResponse.json({ error: "Invalid signature." }, { status: 401 });
  }

  const event = JSON.parse(rawBody);
  // TODO: Handle order_created, subscription_created, subscription_updated,
  // subscription_cancelled, and subscription_expired. Store customer entitlement
  // server-side; never trust a browser token counter for billing enforcement.
  return NextResponse.json({ received: true, event: event.meta?.event_name ?? "unknown" });
}